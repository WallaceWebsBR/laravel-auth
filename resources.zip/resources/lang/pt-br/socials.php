<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Socialite and Social Media Language Lines
    |--------------------------------------------------------------------------
    |
    */

    'denied'          => 'Você não compartilhou suas informações com o nosso aplicativo ',
    'noProvider'      => 'Não encontrado ',
    'registerSuccess' => 'Você foi registrado com sucesso! ',

];
