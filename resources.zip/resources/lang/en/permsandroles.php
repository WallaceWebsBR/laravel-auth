<?php

return [

    // Permissions
    'permissionView'   => 'View',
    'permissionCreate' => 'Create',
    'permissionEdit'   => 'Edit',
    'permissionDelete' => 'Delete',

];
