<?php

return [

    // Permissions
    'permissionView'   => 'Voir',
    'permissionCreate' => 'Créer',
    'permissionEdit'   => 'Editer',
    'permissionDelete' => 'Supprimer',

];
